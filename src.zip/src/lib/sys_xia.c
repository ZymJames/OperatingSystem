#include "stdio.h"

PUBLIC int sys_xia()
{
	disp_str('g');
	return 0;
}
