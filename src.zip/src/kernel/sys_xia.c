#include "stdio.h"

PUBLIC int sys_xia()
{
	saolei(0);
	return 0;
}
