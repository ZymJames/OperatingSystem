#include "stdio.h"

char bufr[128] = {0};
char num1str[128] = {0};
char num2str[128] = {0};
int getNum(char * buft)
{
	int ten = 1, i = 0, res = 0;
	for (i = 0; i < strlen(buft) - 1; i++)
	{
		ten *= 10;
	}
	for (i = 0; i < strlen(buft); i++)
	{
		res += (buft[i] - '0') * ten;
		ten /= 10;
	}
	return res;
}

int main(int argc, char * argv[])
{
	int r, num1 = 0, num2 = 0, flag = 1, res = 0;
	for(int i=0;i < 128;i++)
	{
		bufr[i] = 0;
		num1str[i] = 0;
		num2str[i] = 0;
	}
	
	printf("***************************************************\n");
	printf("*               My Calculator                     *\n");
	printf("***************************************************\n\n");
	while(flag == 1){
		for(int i=0;i < 128;i++)
		{
			bufr[i] = 0;
			num1str[i] = 0;
			num2str[i] = 0;
		}	
		printf("Please input:");
		r = read(0, bufr, 128);
		char operator;
		if (bufr[0] == 'q')
			break;
		//////////////////////////////
		int t = 0; //11+11
		for(int i=0; bufr[i] != 0; i++)
		{
			if(bufr[i] == '+'||bufr[i] == '-'||bufr[i] == '*'||
				bufr[i] == '/')
			{
				operator = bufr[i];
				t = i;
				continue;
			}
			if(t == 0) //num1
			{
				num1str[i] = bufr[i];
			}
			else
			{
				num2str[i-t-1] = bufr[i];
			}
			
			
		}
		num1 = getNum(num1str);
		num2 = getNum(num2str);
		
		switch(operator)
		{
			case '+':
				res = num1 + num2;
				printf(" = %d\n", res);
				break;
			case '-':
				res = num1 - num2;
				printf(" = %d\n",  res);
				break;
			case '*':
				res = num1 * num2;
				printf(" = %d\n",  res);
				break;
			case '/':
				if(num2 <= 0)
				{
					printf("Num2 = Zero!\n");
					break;
				}
				res = num1 / num2;
				printf(" = %d\n", res);
				break;
			case 'q':
				flag = 0;
				break;
			default:
				printf("No such command!\n");
		}
	}
	return 0;
}


