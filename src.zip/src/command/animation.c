#include "stdio.h"
/*#include "type.h"
#include "const.h"
#include "protect.h"
#include "string.h"
#include "fs.h"
#include "proc.h"
#include "tty.h"
#include "console.h"
#include "global.h"
#include "proto.h"*/


void milli_delay2(int a)
{
	for(int i = 0;i < a;i++)
	{
		for(int j = 0;j < 300;j++)
		{	
			j / 7;
		}
	}
}
/**********************************clear*************************************/
void clear()
{
	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
}
/*********************************print_space***********************************/
void print_space(int a)
{
	for(int i = 0; i < a;i++)
		printf(" ");
}
/********************************print_n************************************/
void print_n(int a)
{
	for(int i = 0; i < 7;i++)
		printf("\n");
}
/*****************************************************************************
 *                                animation
 *****************************************************************************/
/**
 * An animation 
 *
 *****************************************************************************/
int main(int argc, char * argv[])
{

int i = 0;
clear();
 print_space(42);
 printf("     `;-.          ___,\n");
 print_space(42);
 printf("       `.`\\_...._/`.-\"`\n");
 print_space(42);
 printf("         \\        /      ,\n");
 print_space(42);
 printf("         /()   () \\    .' `-._\n");
 print_space(42);
 printf("        |)  .    ()\\  /   _.'\n");
 print_space(42);
 printf("        \\  -'-     ,; '. <\n");
 print_space(42);
 printf("         ;.__     ,;|   > \n");
 print_space(42);
 printf("        / ,    / ,  |.-'.-'\n");
 print_space(42);
 printf("       (_/    (_/ ,;|.<`\n");
 print_space(42);
 printf("         \\    ,     ;-`\n");
 print_space(42);
 printf("          >   \\    /\n");
 print_space(42);
 printf("         (_,-'`> .'\n");
 print_space(42);
 printf("              (_,' \n");
 print_n(14);
milli_delay2(1500);


clear();
 print_space(36);
 printf("     `;-.          ___,\n");
 print_space(36);
 printf("       `.`\\_...._/`.-\"`\n");
 print_space(36);
 printf("         \\        /      ,\n");
 print_space(36);
 printf("         /()   () \\    .' `-._\n");
 print_space(36);
 printf("        |)  .    ()\\  /   _.'\n");
 print_space(36);
 printf("        \\  -'-     ,; '. <\n");
 print_space(36);
 printf("         ;.__     ,;|   > \n");
 print_space(36);
 printf("        / ,    / ,  |.-'.-'\n");
 print_space(36);
 printf("       (_/    (_/ ,;|.<`\n");
 print_space(36);
 printf("         \\    ,     ;-`\n");
 print_space(36);
 printf("          >   \\    /\n");
 print_space(36);
 printf("         (_,-'`> .'\n");
 print_space(36);
 printf("              (_,' \n");
 print_n(12);
milli_delay2(3000);


clear();
 print_space(30);
 printf("     `;-.          ___,\n");
 print_space(30);
 printf("       `.`\\_...._/`.-\"`\n");
 print_space(30);
 printf("         \\        /      ,\n");
 print_space(30);
 printf("         /()   () \\    .' `-._\n");
 print_space(30);
 printf("        |)  .    ()\\  /   _.'\n");
 print_space(30);
 printf("        \\  -'-     ,; '. <\n");
 print_space(30);
 printf("         ;.__     ,;|   > \n");
 print_space(30);
 printf("        / ,    / ,  |.-'.-'\n");
 print_space(30);
 printf("       (_/    (_/ ,;|.<`\n");
 print_space(30);
 printf("         \\    ,     ;-`\n");
 print_space(30);
 printf("          >   \\    /\n");
 print_space(30);
 printf("         (_,-'`> .'\n");
 print_space(30);
 printf("              (_,' \n");
 print_n(10);
milli_delay2(3000);

clear();
 print_space(24);
 printf("     `;-.          ___,\n");
 print_space(24);
 printf("       `.`\\_...._/`.-\"`\n");
 print_space(24);
 printf("         \\        /      ,\n");
 print_space(24);
 printf("         /()   () \\    .' `-._\n");
 print_space(24);
 printf("        |)  .    ()\\  /   _.'\n");
 print_space(24);
 printf("        \\  -'-     ,; '. <\n");
 print_space(24);
 printf("         ;.__     ,;|   > \n");
 print_space(24);
 printf("        / ,    / ,  |.-'.-'\n");
 print_space(24);
 printf("       (_/    (_/ ,;|.<`\n");
 print_space(24);
 printf("         \\    ,     ;-`\n");
 print_space(24);
 printf("          >   \\    /\n");
 print_space(24);
 printf("         (_,-'`> .'\n");
 print_space(24);
 printf("              (_,' \n");
 print_n(8);
milli_delay2(3000);


clear();
 print_space(18);
 printf("     `;-.          ___,\n");
 print_space(18);
 printf("       `.`\\_...._/`.-\"`\n");
 print_space(18);
 printf("         \\        /      ,\n");
 print_space(18);
 printf("         /()   () \\    .' `-._\n");
 print_space(18);
 printf("        |)  .    ()\\  /   _.'\n");
 print_space(18);
 printf("        \\  -'-     ,; '. <\n");
 print_space(18);
 printf("         ;.__     ,;|   > \n");
 print_space(18);
 printf("        / ,    / ,  |.-'.-'\n");
 print_space(18);
 printf("       (_/    (_/ ,;|.<`\n");
 print_space(18);
 printf("         \\    ,     ;-`\n");
 print_space(18);
 printf("          >   \\    /\n");
 print_space(18);
 printf("         (_,-'`> .'\n");
 print_space(18);
 printf("              (_,' \n");
 print_n(6);
milli_delay2(3000);


clear();
 print_space(12);
 printf("     `;-.          ___,\n");
 print_space(12);
 printf("       `.`\\_...._/`.-\"`\n");
 print_space(12);
 printf("         \\        /      ,\n");
 print_space(12);
 printf("         /()   () \\    .' `-._\n");
 print_space(12);
 printf("        |)  .    ()\\  /   _.'\n");
 print_space(12);
 printf("        \\  -'-     ,; '. <\n");
 print_space(12);
 printf("         ;.__     ,;|   > \n");
 print_space(12);
 printf("        / ,    / ,  |.-'.-'\n");
 print_space(12);
 printf("       (_/    (_/ ,;|.<`\n");
 print_space(12);
 printf("         \\    ,     ;-`\n");
 print_space(12);
 printf("          >   \\    /\n");
 print_space(12);
 printf("         (_,-'`> .'\n");
 print_space(12);
 printf("              (_,' \n");
 print_n(4);
milli_delay2(3000);

clear();
 print_space(6);
 printf("     `;-.          ___,\n");
 print_space(6);
 printf("       `.`\\_...._/`.-\"`\n");
 print_space(6);
 printf("         \\        /      ,\n");
 print_space(6);
 printf("         /()   () \\    .' `-._\n");
 print_space(6);
 printf("        |)  .    ()\\  /   _.'\n");
 print_space(6);
 printf("        \\  -'-     ,; '. <\n");
 print_space(6);
 printf("         ;.__     ,;|   > \n");
 print_space(6);
 printf("        / ,    / ,  |.-'.-'\n");
 print_space(6);
 printf("       (_/    (_/ ,;|.<`\n");
 print_space(6);
 printf("         \\    ,     ;-`\n");
 print_space(6);
 printf("          >   \\    /\n");
 print_space(6);
 printf("         (_,-'`> .'\n");
 print_space(6);
 printf("              (_,' \n");
 print_n(2);
milli_delay2(3000);

clear();
 printf("     `;-.          ___,\n");
 printf("       `.`\\_...._/`.-\"`\n");
 printf("         \\        /      ,\n");
 printf("         /()   () \\    .' `-._\n");
 printf("        |)  .    ()\\  /   _.'\n");
 printf("        \\  -'-     ,; '. <\n");
 printf("         ;.__     ,;|   > \n");
 printf("        / ,    / ,  |.-'.-'\n");
 printf("       (_/    (_/ ,;|.<`\n");
 printf("         \\    ,     ;-`\n");
 printf("          >   \\    /\n");
 printf("         (_,-'`> .'\n");
 printf("              (_,' \n");
 print_n(2);
milli_delay2(3000);
 
 return 0;
}
